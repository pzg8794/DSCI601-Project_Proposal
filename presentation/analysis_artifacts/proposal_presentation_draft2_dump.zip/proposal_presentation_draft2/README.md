# Proposal Presentation Draft 2

This directory contains the final-presentation draft for the DSCI601 project.

Main file:

- `proposal_presentation_draft2.tex`

Optional local figure assets:

- `figures/fig1_testing_network.pdf`
- `figures/fig2_routing_counterfactual.pdf`
- `figures/fig3_pulseox_bias.pdf`
- `figures/fig4_confusion_matrices.pdf`
- `figures/fig5_utility_fairness_frontier.pdf`

The LaTeX source is Overleaf-safe: it uses `\IfFileExists` to load the image files when present, and falls back to TikZ/PGFPlots/table versions if the images are missing. This means the `.tex` can compile even if the binary figure files are not yet uploaded to Overleaf.

Compile from this directory with:

```bash
pdflatex proposal_presentation_draft2.tex
pdflatex proposal_presentation_draft2.tex
```

The deck integrates the new COVID clinical foundation analysis:

1. COVID testing access and fair CMAB routing.
2. Pulse oximetry bias as a stronger diagnostic-bias case than unsupported PCR/antigen false-positive claims.
3. Confusion-matrix findings for routing false negatives and diagnostic missed hypoxemia.
4. Architecture, code-review targets, demo plan, results, limitations, and next-semester plan.
