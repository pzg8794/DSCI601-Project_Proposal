from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np

OUT = Path('/mnt/data/proposal_presentation_draft2/figures')
OUT.mkdir(parents=True, exist_ok=True)

# Shared colors
orange = '#f76902'
blue = '#1f4e79'
green = '#48a062'
red = '#be4b48'
purple = '#8763ab'
gray = '#6e7781'
light = '#f5f7fa'

# Figure 1: network-like routing diagram
fig, ax = plt.subplots(figsize=(11.5, 6.6))
ax.set_xlim(0, 10)
ax.set_ylim(0, 7)
ax.axis('off')
ax.set_title('COVID test routing: context-blind access misaligned with burden', fontsize=16, weight='bold', pad=14)
# Site nodes
sites = {
    'Large hospital hub\n1200/day': (1.0, 5.8, 1200),
    'Regional center\n900/day': (3.2, 5.8, 900),
    'Clinic\n400/day': (5.3, 5.8, 400),
    'Urgent care\n350/day': (7.2, 5.8, 350),
    'Mobile unit\n150/day': (9.0, 5.8, 150),
}
communities = {
    'Low-SVI White\n720 cases/100k\n8.9 tests/1k/wk': (1.1, 1.0, 720, blue),
    'Low-SVI Mixed\n890 cases/100k\n7.4 tests/1k/wk': (3.0, 1.0, 890, blue),
    'High-SVI Mixed\n2290 cases/100k\n3.1 tests/1k/wk': (5.1, 1.0, 2290, orange),
    'High-SVI Black\n2410 cases/100k\n2.7 tests/1k/wk': (7.1, 1.0, 2410, red),
    'High-SVI Hispanic\n3100 cases/100k\n2.1 tests/1k/wk': (9.0, 1.0, 3100, purple),
}
# Edges: (site index, community label, weight, color)
site_list = list(sites.values())
comm_items = list(communities.items())
edges = [(0,0,10,blue),(1,1,8,blue),(2,2,4,gray),(3,2,4,gray),(0,3,2,red),(1,4,2,red),(4,3,3,red),(4,4,3,red)]
for si, ci, w, c in edges:
    sx, sy, _ = site_list[si]
    _, (cx, cy, _, _) = comm_items[ci]
    ax.annotate('', xy=(cx, cy+0.35), xytext=(sx, sy-0.35), arrowprops=dict(arrowstyle='->', lw=w/2.0, color=c, alpha=0.55))
for label,(x,y,cap) in sites.items():
    ax.scatter([x],[y], s=cap/1.2, color='#34495e', zorder=3)
    ax.text(x, y, label, color='white', fontsize=8, ha='center', va='center', weight='bold')
for label,(x,y,burden,c) in communities.items():
    ax.scatter([x],[y], s=burden/2.2, color=c, zorder=3, alpha=0.95)
    ax.text(x, y-0.82, label, fontsize=8, ha='center', va='top')
ax.text(0.2, 6.55, 'Testing resources', fontsize=11, weight='bold')
ax.text(0.2, 2.25, 'Communities sized by COVID burden', fontsize=11, weight='bold')
ax.text(0.2, 0.15, 'Blue edges = over-served relative to burden; red edges = under-served high-vulnerability communities.', fontsize=9)
fig.tight_layout()
for ext in ['png','pdf']:
    fig.savefig(OUT / f'fig1_testing_network.{ext}', dpi=220, bbox_inches='tight')
plt.close(fig)

# Figure 2: routing bar chart
labels = ['High-SVI\nHispanic','High-SVI\nBlack','High-SVI\nMixed','Low-SVI\nWhite','Low-SVI\nMixed']
actual = np.array([2.1,2.7,3.1,8.9,7.4])
fair = np.array([8.4,7.9,6.8,4.2,3.8])
burden = np.array([3100,2410,2290,720,890])
x = np.arange(len(labels))
fig, ax1 = plt.subplots(figsize=(10.5,6.0))
w = 0.36
ax1.bar(x-w/2, actual, w, label='Actual / context-blind', color=red)
ax1.bar(x+w/2, fair, w, label='Fair CMAB + EQUITAS target', color=green)
ax1.set_ylabel('Tests per 1,000 residents per week')
ax1.set_xticks(x, labels)
ax1.set_ylim(0,10)
ax1.set_title('Fair CMAB reverses the burden/access mismatch', fontsize=15, weight='bold')
ax2 = ax1.twinx()
ax2.plot(x, burden, marker='o', color=blue, linewidth=2, label='Burden index')
ax2.set_ylabel('COVID burden proxy: cases per 100k')
ax2.set_ylim(0,3400)
lines1, labs1 = ax1.get_legend_handles_labels()
lines2, labs2 = ax2.get_legend_handles_labels()
ax1.legend(lines1+lines2, labs1+labs2, loc='upper center', ncol=3, frameon=False)
ax1.grid(axis='y', alpha=0.2)
fig.tight_layout()
for ext in ['png','pdf']:
    fig.savefig(OUT / f'fig2_routing_counterfactual.{ext}', dpi=220, bbox_inches='tight')
plt.close(fig)

# Figure 3: pulse-ox bias chart
labels = ['White','Asian','Black','Hispanic']
fawzy = np.array([17.2,30.2,28.5,29.8])
sjoding = np.array([3.6,0,11.7,0])
fig, ax = plt.subplots(figsize=(9.5,5.8))
x = np.arange(len(labels))
ax.bar(x-0.18, fawzy, 0.36, label='Fawzy 2022 COVID cohort', color=purple)
ax.bar(x+0.18, sjoding, 0.36, label='Sjoding 2020 paired-measure signal', color=orange)
ax.set_ylabel('Occult hypoxemia rate (%)')
ax.set_ylim(0,35)
ax.set_xticks(x, labels)
ax.set_title('Same diagnostic threshold, unequal reliability by group', fontsize=15, weight='bold')
ax.legend(frameon=False)
ax.grid(axis='y', alpha=0.2)
for i,v in enumerate(fawzy): ax.text(i-0.18, v+0.8, f'{v:.1f}', ha='center', fontsize=9)
for i,v in enumerate(sjoding):
    if v > 0: ax.text(i+0.18, v+0.8, f'{v:.1f}', ha='center', fontsize=9)
fig.tight_layout()
for ext in ['png','pdf']:
    fig.savefig(OUT / f'fig3_pulseox_bias.{ext}', dpi=220, bbox_inches='tight')
plt.close(fig)

# Figure 4: confusion matrices
mats = [
    ('Routing baseline\nHigh-SVI Hispanic', np.array([[21,5],[79,45]])),
    ('Routing fair CMAB\nHigh-SVI Hispanic', np.array([[76,14],[24,36]])),
    ('Pulse-ox baseline\nBlack patients', np.array([[71,7],[29,93]])),
    ('Pulse-ox EQUITAS\nBlack patients', np.array([[94,11],[6,89]])),
]
fig, axes = plt.subplots(1,4,figsize=(13.2,3.7))
for ax,(title,mat) in zip(axes,mats):
    im=ax.imshow(mat, cmap='Blues')
    ax.set_title(title, fontsize=10, weight='bold')
    ax.set_xticks([0,1], ['Pred +','Pred -'], fontsize=8)
    ax.set_yticks([0,1], ['Actual +','Actual -'], fontsize=8)
    for (i,j),v in np.ndenumerate(mat):
        ax.text(j,i,str(v),ha='center',va='center',fontsize=11,weight='bold',color='black')
    ax.tick_params(length=0)
fig.suptitle('Confusion matrices: false negatives fall when context is used', fontsize=15, weight='bold')
fig.tight_layout()
for ext in ['png','pdf']:
    fig.savefig(OUT / f'fig4_confusion_matrices.{ext}', dpi=220, bbox_inches='tight')
plt.close(fig)

# Figure 5: frontier
policies = ['Baseline','Utility-only\nCMAB','Fair CMAB','EQUITAS\ncalibrated']
utility = [72,84,88,91]
gap = [25,18,6,2]
fig, ax = plt.subplots(figsize=(8.8,5.4))
ax.plot(utility, gap, marker='o', color=blue, linewidth=2.5)
for x0,y0,label in zip(utility,gap,policies):
    ax.text(x0+0.3, y0+0.7, label, fontsize=9)
ax.set_xlabel('Utility / clinical efficiency index')
ax.set_ylabel('Remaining group disparity gap (percentage points)')
ax.set_ylim(0,30)
ax.set_xlim(68,96)
ax.set_title('EQUITAS targets lower disparity without abandoning utility', fontsize=15, weight='bold')
ax.grid(alpha=0.25)
fig.tight_layout()
for ext in ['png','pdf']:
    fig.savefig(OUT / f'fig5_utility_fairness_frontier.{ext}', dpi=220, bbox_inches='tight')
plt.close(fig)

print('created figures:', len(list(OUT.glob('*'))))
